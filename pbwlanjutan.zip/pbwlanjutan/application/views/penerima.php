<?php
echo "data yang dikirimkan adalah ".$testing."<br>";
echo "umur yang dimasukkan adalah ".$testing2;
?>